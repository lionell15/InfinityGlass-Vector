#!/system/bin/sh
# Executed by KernelSU Next installer; fail closed on unexpected ROM.
ui_print ' ' 
ui_print 'Smart Pixels for oz7wm HOS4 - rodin / Android 17'
[ "$(getprop ro.build.version.sdk)" = "37" ] || abort 'ERROR: requires Android 17, SDK 37.'
DEV="$(getprop ro.product.device)"
[ "$DEV" = "rodin" ] || abort "ERROR: requires rodin (detected $DEV)"
SYSTEMUI_PATH="$(pm path com.android.systemui | sed -n 's/^package://p' | head -n 1)"
[ -n "$SYSTEMUI_PATH" ] && [ -r "$SYSTEMUI_PATH" ] || abort 'ERROR: cannot locate SystemUI.'
EXPECTED="$(cat "$MODPATH/sysui.sha256")"
ACTUAL="$(sha256sum "$SYSTEMUI_PATH" | cut -d ' ' -f1)"
[ "$ACTUAL" = "$EXPECTED" ] || abort 'ERROR: oz7wm SystemUI.apk fingerprint differs. Installation refused.'
[ -s "$MODPATH/app/SmartPixels-oz7wm.apk" ] || abort 'ERROR: compiled companion APK not included. Refusing incomplete module.'
ui_print 'SystemUI firmware fingerprint: verified.'
ui_print 'SystemUI.apk is NOT replaced or modified.'
ui_print 'App installs after boot; enable its SystemUI scope in Vector, then reboot.'
set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm "$MODPATH/service.sh" 0 0 0755
set_perm "$MODPATH/action.sh" 0 0 0755
set_perm "$MODPATH/uninstall.sh" 0 0 0755
