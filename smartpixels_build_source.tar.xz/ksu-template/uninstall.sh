#!/system/bin/sh
# Remove only our installed companion; don't touch SystemUI.apk or user ROM.
pm uninstall --user 0 com.fk.smartpixelsposed.oz7wm >/dev/null 2>&1 || true
