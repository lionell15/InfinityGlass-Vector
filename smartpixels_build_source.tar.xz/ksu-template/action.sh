#!/system/bin/sh
am start -n com.fk.smartpixelsposed.oz7wm/com.fk.smartpixelsposed.MainActivity >/dev/null 2>&1
