#!/system/bin/sh
# Only install the already compiled Xposed APK. No partition replacements.
MODDIR=${0%/*}
LOG="$MODDIR/install.log"
TARGET=com.fk.smartpixelsposed.oz7wm
APK="$MODDIR/app/SmartPixels-oz7wm.apk"
(
  i=0
  while [ "$(getprop sys.boot_completed)" != "1" ] && [ "$i" -lt 120 ]; do
    sleep 2
    i=$((i + 1))
  done
  if [ "$(getprop sys.boot_completed)" != "1" ]; then
    echo 'Boot was not completed. APK installation skipped.' > "$LOG"
    exit 0
  fi
  if pm path "$TARGET" >/dev/null 2>&1; then
    echo 'Companion already installed. No package changes.' > "$LOG"
    exit 0
  fi
  echo 'Installing Xposed companion in regular app space...' > "$LOG"
  STAGED=/data/local/tmp/smartpixels-oz7wm-staged.apk
  cp "$APK" "$STAGED" || { echo 'ERROR: staging failed' >> "$LOG"; exit 0; }
  chmod 0644 "$STAGED"
  pm install -r "$STAGED" >> "$LOG" 2>&1
  rm -f "$STAGED"
  if ! pm path "$TARGET" >/dev/null 2>&1; then
    echo 'ERROR: companion installation failed; see log.' >> "$LOG"
  else
    echo 'OK. Set com.android.systemui as the only scope in Vector/LSPosed and reboot.' >> "$LOG"
  fi
) &
