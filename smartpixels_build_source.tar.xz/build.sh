#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
ROOT="$PWD"
UPSTREAM=https://github.com/frknkrc44/SmartPiXelsPosed.git
LOCKED_COMMIT=306174899f0e7233dce1c475b796b6313eefc705
if [ -e "$ROOT/vendor/SmartPiXelsPosed" ]; then
  echo 'ERROR: vendor/SmartPiXelsPosed already exists. For reproducibility, remove it first.' >&2
  exit 1
fi
mkdir -p vendor out
printf '[1/5] Download original source pinned to %s\n' "$LOCKED_COMMIT"
git clone --quiet "$UPSTREAM" vendor/SmartPiXelsPosed
git -C vendor/SmartPiXelsPosed checkout --quiet "$LOCKED_COMMIT"
test "$(git -C vendor/SmartPiXelsPosed rev-parse HEAD)" = "$LOCKED_COMMIT"
printf '[2/5] Apply source-level Android 17 oz7wm adapter\n'
python3 "$ROOT/patch/apply_patch.py" "$ROOT/vendor/SmartPiXelsPosed"
printf '[3/5] Compile Xposed companion using Android SDK 37\n'
cd vendor/SmartPiXelsPosed
chmod +x gradlew
./gradlew --no-daemon :app:assembleDebug
cd "$ROOT"
APK="$(find vendor/SmartPiXelsPosed/app/build/outputs/apk/debug -type f -name '*.apk' | head -1)"
test -n "$APK" && test -s "$APK"
cp "$APK" out/SmartPixels-oz7wm-A17-rc1.apk
printf '[4/5] Create KernelSU Next systemless installation package\n'
mkdir -p out/ksu-build/app
cp -a ksu-template/. out/ksu-build/
cp "$APK" out/ksu-build/app/SmartPixels-oz7wm.apk
(cd out/ksu-build && zip -q -r ../SmartPixels_OZ7WM_A17_KernelSU_Next_rc1.zip .)
printf '[5/5] Finished; these artifacts still need on-device testing\n'
ls -lh out/SmartPixels-oz7wm-A17-rc1.apk out/SmartPixels_OZ7WM_A17_KernelSU_Next_rc1.zip
