// Copyright (C) 2026 Smart Pixels oz7wm adaptation
// SPDX-License-Identifier: AGPL-3.0-or-later
// Derivative of https://github.com/frknkrc44/SmartPiXelsPosed
package com.fk.smartpixelsposed;

import android.app.Application;
import android.app.Service;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.res.Configuration;
import android.hardware.display.DisplayManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;

import com.android.systemui.smartpixels.SmartPixelsService;

import java.lang.reflect.Method;
import java.io.FileInputStream;
import java.security.MessageDigest;
import java.util.concurrent.atomic.AtomicBoolean;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Source-specific adapter. No replacement of Xiaomi SystemUI.apk is attempted.
 * Runs only in the main SystemUI process when the KernelSU property guard is on.
 * The original SmartPixelsService/Grids overlay engine is preserved.
 */
public final class Oz7wmModuleMain implements IXposedHookLoadPackage {
    private static final String TAG = "[SmartPixels-oz7wm] ";
    private static final String SYSUI = "com.android.systemui";
    private static final String GUARD_PROP = "ro.smartpixels.oz7wm";
    private static final String ROM_SHA256 = "4f2f59553b09804820c682581755e6542b0593bbd10341ae8c7ec4e825b5301a";
    private static final AtomicBoolean scheduled = new AtomicBoolean(false);
    private static final AtomicBoolean initialized = new AtomicBoolean(false);

    private Handler handler;
    private volatile SmartPixelsService service;
    private DisplayManager displays;
    private DisplayManager.DisplayListener listener;
    private ComponentCallbacks configListener;

    private static boolean guardEnabled() {
        try {
            Class<?> sp = Class.forName("android.os.SystemProperties");
            Method get = sp.getDeclaredMethod("get", String.class, String.class);
            get.setAccessible(true);
            return "1".equals(get.invoke(null, GUARD_PROP, "0"));
        } catch (Throwable error) {
            XposedBridge.log(TAG + "guard property unavailable: " + error);
            return false; // fail closed if module was disabled, e.g. in recovery
        }
    }

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam p) {
        if (!SYSUI.equals(p.packageName) || !SYSUI.equals(p.processName)) return;
        if (Build.VERSION.SDK_INT != 37 || !"rodin".equalsIgnoreCase(Build.DEVICE)) {
            XposedBridge.log(TAG + "unsupported device/API: " + Build.DEVICE + "/" + Build.VERSION.SDK_INT);
            return;
        }
        if (!guardEnabled()) {
            XposedBridge.log(TAG + "KernelSU companion module disabled; no hooks registered");
            return;
        }
        // Confirmed from the SystemUI.apk uploaded by the owner: this lifecycle exists.
        try {
            XposedHelpers.findAndHookMethod(
                "com.android.systemui.SystemUIService", p.classLoader,
                "onCreate", new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam h) {
                        Context context = ((Service) h.thisObject).getApplicationContext();
                        schedule(context, 1200);
                    }
                }
            );
            XposedBridge.log(TAG + "SystemUIService lifecycle hook registered");
        } catch (Throwable t) {
            XposedBridge.log(TAG + "SystemUIService hook unavailable: " + t);
        }
        // Fallback when service lifecycle changes; deduplicated with service hook.
        try {
            XposedHelpers.findAndHookMethod(Application.class, "attach", Context.class,
                new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam h) {
                        schedule((Context) h.args[0], 4000);
                    }
                });
        } catch (Throwable t) {
            XposedBridge.log(TAG + "Application.attach fallback unavailable: " + t);
        }
    }

    private void schedule(Context c, long delay) {
        if (c == null || !scheduled.compareAndSet(false, true)) return;
        Context app = c.getApplicationContext();
        // Verify this exact SystemUI.apk outside main thread to avoid ANRs.
        new Thread(() -> {
            if (!romFingerprintMatches(app)) {
                XposedBridge.log(TAG + "ROM fingerprint mismatch; refusing to activate");
                return;
            }
            Handler main = new Handler(Looper.getMainLooper());
            main.postDelayed(() -> initialize(app), delay);
        }, "oz7wm-smartpixels-verify").start();
    }

    private static boolean romFingerprintMatches(Context c) {
        try {
            String path = c.getPackageManager().getApplicationInfo(SYSUI, 0).sourceDir;
            MessageDigest sha = MessageDigest.getInstance("SHA-256");
            try (FileInputStream in = new FileInputStream(path)) {
                byte[] bytes = new byte[65536];
                int count;
                while ((count = in.read(bytes)) != -1) sha.update(bytes, 0, count);
            }
            StringBuilder hex = new StringBuilder();
            for (byte b : sha.digest()) hex.append(String.format("%02x", b & 0xff));
            return ROM_SHA256.contentEquals(hex);
        } catch (Throwable t) {
            XposedBridge.log(TAG + "ROM verification failed: " + t);
            return false;
        }
    }

    private void initialize(Context ctx) {
        if (ctx == null || !initialized.compareAndSet(false, true)) return;
        try {
            handler = new Handler(Looper.getMainLooper());
            service = new SmartPixelsService(ctx, handler) {
                @Override protected void onSettingsUpdated() {
                    // Unlike old ports, no dependency on status bar view methods.
                }
            };
            service.useAlternativeMethodForBS = false; // observe Android low_power directly
            service.usingAltLogic = true;

            configListener = new ComponentCallbacks() {
                @Override public void onConfigurationChanged(Configuration c) {
                    try { if (service != null) service.onConfigurationChanged(c); }
                    catch (Throwable t) { XposedBridge.log(TAG + "configuration: " + t); }
                }
                @Override public void onLowMemory() { }
            };
            ctx.registerComponentCallbacks(configListener);
            displays = (DisplayManager) ctx.getSystemService(Context.DISPLAY_SERVICE);
            if (displays != null) {
                listener = new DisplayManager.DisplayListener() {
                    @Override public void onDisplayAdded(int id) { }
                    @Override public void onDisplayRemoved(int id) { }
                    @Override public void onDisplayChanged(int id) {
                        if (id == Display.DEFAULT_DISPLAY) refreshDisplayState();
                    }
                };
                displays.registerDisplayListener(listener, handler);
            }
            // Always run once to register Settings observers + broadcast receiver.
            // The adapted engine does not add any overlay while disabled.
            service.startFilter();
            refreshDisplayState();
            XposedBridge.log(TAG + "Smart Pixels started (initial setting is disabled)");
        } catch (Throwable t) {
            XposedBridge.log(TAG + "init exception: " + t);
            try { if (service != null) service.onDestroy(); } catch (Throwable ignored) { }
            service = null;
            initialized.set(false);
        }
    }

    private void refreshDisplayState() {
        try {
            if (service == null || displays == null) return;
            Display d = displays.getDisplay(Display.DEFAULT_DISPLAY);
            if (d != null && d.getState() == Display.STATE_ON) {
                service.reloadFilter();
            } else {
                service.stopFilter();
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + "display state: " + t);
        }
    }
}
