#!/usr/bin/env python3
"""Fail-closed reproducible patch against SmartPiXelsPosed commit 30617489.
Written files are only saved after every required anchor has been validated.
"""
from pathlib import Path
import argparse, shutil, sys
parser=argparse.ArgumentParser()
parser.add_argument('upstream', help='directory with source checkout')
args=parser.parse_args()
root=Path(args.upstream).resolve()
here=Path(__file__).resolve().parent
src=root/'app/src/main/java/com/fk/smartpixelsposed'
entry=root/'app/src/main/assets/xposed_init'
engine=root/'app/src/main/java/com/android/systemui/smartpixels/SmartPixelsService.java'
get=src/'SafeValueGetter.java'
main=src/'MainActivity.java'
tile=src/'SmartPixelsTile.java'
appgradle=root/'app/build.gradle'
manifest=root/'app/src/main/AndroidManifest.xml'
needed=[entry,engine,get,main,tile,appgradle,manifest]
if not all(x.is_file() for x in needed):
    sys.exit('FAIL: upstream project incomplete; no files changed')
mods={}

def rep(p,old,new):
    text=mods.get(p, p.read_text(encoding='utf-8'))
    if text.count(old)!=1:
        sys.exit('FAIL: missing or ambiguous anchor in '+str(p)+'; no files changed')
    mods[p]=text.replace(old,new,1)

rep(entry, 'com.fk.smartpixelsposed.ModuleMain', 'com.fk.smartpixelsposed.Oz7wmModuleMain')
# Fully qualified names prevent a changed applicationId from changing activities.
rep(manifest, 'android:name=".MainActivity"', 'android:name="com.fk.smartpixelsposed.MainActivity"')
rep(manifest, 'android:name=".SmartPixelsTile"', 'android:name="com.fk.smartpixelsposed.SmartPixelsTile"')
rep(get, '                SettingsSystem.SMART_PIXELS_ENABLED,\n                1\n',
    '                SettingsSystem.SMART_PIXELS_ENABLED,\n                0 // off until user enables manually\n')
rep(main, '    public boolean isEnabled() {\n        return false;\n    }',
    '    public boolean isEnabled() {\n        return true; // Xposed status checked in SystemUI logs\n    }')
rep(main, '        Intent refreshIntent = new Intent(SmartPixelsService.INTENT_ACTION);\n        refreshIntent.putExtra(key, value);',
    '        Intent refreshIntent = new Intent(SmartPixelsService.INTENT_ACTION);\n        refreshIntent.setPackage("com.android.systemui");\n        refreshIntent.putExtra(key, value);')
rep(tile, '        Intent refreshIntent = new Intent(SmartPixelsService.INTENT_ACTION);\n        refreshIntent.putExtra(',
    '        Intent refreshIntent = new Intent(SmartPixelsService.INTENT_ACTION);\n        refreshIntent.setPackage("com.android.systemui");\n        refreshIntent.putExtra(')
rep(main, '        percentTimeoutSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {',
    '        findViewById(R.id.settings_enabled_system_bars_shifting).setVisibility(View.GONE);\n'
    '        findViewById(R.id.settings_enabled_set_dim_on_sb_drag).setVisibility(View.GONE);\n'
    '        findViewById(R.id.settings_bars_alpha).setVisibility(View.GONE);\n'
    '        percentTimeoutSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {')
rep(appgradle, '        applicationId = namespace', '        applicationId = "com.fk.smartpixelsposed.oz7wm"')
rep(appgradle, '        versionName = "1.15"', '        versionName = "1.15-oz7wm-a17-rc1"')
# Fix observer URIs: these values are written to Settings.System by the service.
for key in ('SMART_PIXELS_ON_POWER_SAVE','SMART_PIXELS_SYSTEM_BARS_SHIFT'):
    rep(engine, 'Settings.Global.getUriFor(SettingsSystem.'+key+')', 'Settings.System.getUriFor(SettingsSystem.'+key+')')
# Retain original grid rendering; replace the startFilter lifecycle only.
text=mods.get(engine, engine.read_text(encoding='utf-8'))
start=text.index('    @SuppressLint("UnspecifiedRegisterReceiverFlag")\n    public void startFilter(){')
end=text.index('    public void reloadFilter() {', start)
replacement='''    @SuppressLint("UnspecifiedRegisterReceiverFlag")
    public void startFilter() {
        if (view != null) return;
        destroyed = false;
        running = false;
        windowManager = (WindowManager) mContext.getSystemService(WINDOW_SERVICE);
        if (mHandler == null) mHandler = new Handler(Looper.getMainLooper());

        // Register observers even if disabled, so the first user toggle works.
        if (mObserver == null) mObserver = new SmartPixelsObserver();
        if (mSettingsIntentFilter == null) {
            mSettingsIntentFilter = new IntentFilter(INTENT_ACTION);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                mContext.registerReceiver(mSettingsReceiver, mSettingsIntentFilter, Context.RECEIVER_EXPORTED);
            } else {
                mContext.registerReceiver(mSettingsReceiver, mSettingsIntentFilter);
            }
        }
        if (!isEnabled()) return; // no unnecessary window on first boot

        try {
            view = new View(mContext);
            view.setLayerType(View.LAYER_TYPE_HARDWARE, null);
            if (draw == null) setNewDrawable();
            else view.setBackground(draw);
            windowManager.addView(view, getLayoutParams());
            running = true;
            reloadFilter();
        } catch (Throwable t) {
            Log.e(LOG, "oz7wm: addView failed; keeping SystemUI alive", t);
            view = null;
            running = false;
        }
    }

'''
mods[engine]=text[:start]+replacement+text[end:]
# On system screens where overlay is not allowed: log error, don't crash SystemUI.
rep(engine, '        if (view.getParent() == null) {\n            windowManager.addView(view, getLayoutParams());\n        }',
    '        if (view.getParent() == null) {\n            try {\n                windowManager.addView(view, getLayoutParams());\n            } catch (Throwable t) {\n                Log.e(LOG, "oz7wm: reattach denied", t);\n                return;\n            }\n        }')
# release broadcast registration safely on service lifecycle destruction.
rep(engine, '        destroyed = true;\n        stopFilter();\n        Log.d(LOG, "Service stopped");',
    '        destroyed = true;\n        stopFilter();\n        if (mSettingsIntentFilter != null) {\n            try { mContext.unregisterReceiver(mSettingsReceiver); }\n            catch (IllegalArgumentException ignored) { }\n            mSettingsIntentFilter = null;\n        }\n        mObserver = null;\n        Log.d(LOG, "Service stopped");')
# Make package permission & own settings safer without directly modifying SystemUI.apk.
replacement_file=src/'Oz7wmModuleMain.java'
if replacement_file.exists(): sys.exit('FAIL: adapter already exists; clean checkout required')
for p,value in mods.items():p.write_text(value,encoding='utf-8')
shutil.copy2(here/'Oz7wmModuleMain.java',replacement_file)
print('OK: patched '+str(len(mods))+' upstream files; original Grid engine unchanged.')
